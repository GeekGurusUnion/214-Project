var searchData=
[
  ['2_20committing_20code_0',['2. Committing Code',['../md_README.html#autotoc_md14',1,'']]],
  ['2_20design_20style_1',['2. Design Style',['../md_README.html#autotoc_md5',1,'']]],
  ['2_20supporting_20branches_2',['4.2. Supporting Branches',['../md_README.html#autotoc_md18',1,'']]],
  ['214_20project_3',['COS 214 Project',['../md_README.html',1,'']]]
];
