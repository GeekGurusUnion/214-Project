var searchData=
[
  ['design_20and_20inheritance_0',['5. Class Design and Inheritance',['../md_README.html#autotoc_md8',1,'']]],
  ['design_20style_1',['2. Design Style',['../md_README.html#autotoc_md5',1,'']]],
  ['destroyinstance_2',['destroyInstance',['../classsi__headChef.html#ab4e7ecb8ae90c9db3ff519648a8f64bd',1,'si_headChef']]],
  ['destruction_20and_20copying_3',['6. Construction, Destruction and Copying',['../md_README.html#autotoc_md9',1,'']]],
  ['doubleburger_4',['doubleburger',['../classDoubleBurger.html',1,'DoubleBurger'],['../classDoubleBurger.html#a59ec8ef665e056949a1f4842020673e4',1,'DoubleBurger::DoubleBurger()']]]
];
