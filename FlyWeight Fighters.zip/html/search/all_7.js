var searchData=
[
  ['ad_5ffloororder_0',['ad_floororder',['../classad__FloorOrder.html#a130baf0fea49fff3f112a159838fb6db',1,'ad_FloorOrder::ad_FloorOrder()'],['../classad__FloorOrder.html',1,'ad_FloorOrder']]],
  ['ad_5ffloororder_2eh_1',['ad_FloorOrder.h',['../ad__FloorOrder_8h.html',1,'']]],
  ['ad_5forderadapter_2',['ad_orderadapter',['../classad__OrderAdapter.html',1,'ad_OrderAdapter'],['../classad__OrderAdapter.html#ad652a3695a742f80d8e5fbf1ff9f28f1',1,'ad_OrderAdapter::ad_OrderAdapter()']]],
  ['ad_5forderadapter_2eh_3',['ad_OrderAdapter.h',['../ad__OrderAdapter_8h.html',1,'']]],
  ['ad_5frestaurantorder_4',['ad_restaurantorder',['../classad__RestaurantOrder.html',1,'ad_RestaurantOrder'],['../classad__RestaurantOrder.html#aa711291aa042ebc2738f685b01c576db',1,'ad_RestaurantOrder::ad_RestaurantOrder()']]],
  ['ad_5frestaurantorder_2eh_5',['ad_RestaurantOrder.h',['../ad__RestaurantOrder_8h.html',1,'']]],
  ['addcolleague_6',['addColleague',['../classMediator.html#ad4473a14489b44b3aba41fa8d1d1d34e',1,'Mediator']]],
  ['addcomponent_7',['addComponent',['../classfa__dish.html#a6f011b05ec7232c15a9df2f2df2050f3',1,'fa_dish']]],
  ['addcustomization_8',['addcustomization',['../classOrder.html#add9497c28bf3db59c28f2c0850c621d4',1,'Order::addCustomization()'],['../classWaiter.html#a659f2989fbdf165f74d9e55d1c02ae2c',1,'Waiter::addCustomization()'],['../classMenuItem.html#acd77a4e9441eb873b55fc660a8b75af9',1,'MenuItem::addCustomization()'],['../classFacade.html#a175a72987576b69d5e27987a6ea976c2',1,'Facade::addCustomization()']]],
  ['adddish_9',['addDish',['../classOrder.html#ac34df81c6d8cf8dee02a62a327995ecf',1,'Order']]],
  ['addingredienthandler_10',['addingredienthandler',['../classAddingredientHandler.html',1,'AddingredientHandler'],['../classAddingredientHandler.html#a441c5071b5a2646113318a46ba31c220',1,'AddingredientHandler::AddingredientHandler()']]],
  ['additem_11',['additem',['../classOrder.html#aaf5b17dbdfbcd8a38efcc68e9df88eb9',1,'Order::addItem()'],['../classWaiter.html#a2733f0fb953cacc86191755a51cd4835',1,'Waiter::addItem(RestaurantTable *rt, std::string m)']]],
  ['addorder_12',['addOrder',['../classWaiter.html#abf1b0a3215a2272a32b7e2f8168b29bf',1,'Waiter']]],
  ['addtable_13',['addTable',['../classFacade.html#ae58a2b82fbf78b5f7bba47f07a47ed77',1,'Facade']]],
  ['addtip_14',['addTip',['../classOrder.html#a0a03d4d2d5279fbcc6108149b456826e',1,'Order']]],
  ['addtoorder_15',['addToOrder',['../classFacade.html#abd1f89ea4832923c46a99b14246384e3',1,'Facade']]],
  ['addwaiter_16',['addWaiter',['../classFacade.html#a3c990c29b97328b95872ebd77ce13aa2',1,'Facade']]],
  ['and_20copying_17',['6. Construction, Destruction and Copying',['../md_README.html#autotoc_md9',1,'']]],
  ['and_20exceptions_18',['7. Error Handling and Exceptions',['../md_README.html#autotoc_md10',1,'']]],
  ['and_20inheritance_19',['5. Class Design and Inheritance',['../md_README.html#autotoc_md8',1,'']]],
  ['and_20operators_20',['4. Functions and Operators',['../md_README.html#autotoc_md7',1,'']]]
];
