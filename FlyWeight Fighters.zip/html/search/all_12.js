var searchData=
[
  ['main_20branches_0',['4.1. Main Branches',['../md_README.html#autotoc_md17',1,'']]],
  ['mediator_1',['mediator',['../classMediator.html',1,'Mediator'],['../classColleague.html#a1f2794ce2658d64993f30b60fcad664e',1,'Colleague::mediator'],['../classMediator.html#aa75ae071194f2da701d98de0f6ac0ba7',1,'Mediator::Mediator()']]],
  ['mediator_2eh_2',['Mediator.h',['../Mediator_8h.html',1,'']]],
  ['members_3',['Members',['../md_README.html#autotoc_md2',1,'']]],
  ['menuitem_4',['menuitem',['../classMenuItem.html',1,'MenuItem'],['../classMenuItem.html#a38619cca675e6e1a2ec1bbd342baa867',1,'MenuItem::MenuItem(std::string name, double price)'],['../classMenuItem.html#af4e7a4a1cb5bbf3e54d2dafe3d7d1506',1,'MenuItem::MenuItem(const MenuItem &amp;other)']]],
  ['menuitem_2eh_5',['MenuItem.h',['../MenuItem_8h.html',1,'']]],
  ['mergetables_6',['mergetables',['../classMergeTables.html',1,'MergeTables'],['../classMergeTables.html#a88fd52bd5e5e3351d665ac78bec5ba24',1,'MergeTables::MergeTables()'],['../classFacade.html#a631a10c751e1e87eceaa52fdebdc4e0e',1,'Facade::mergeTables()'],['../classWaiter.html#a0a6556ef9e60ad452423769a508d09b0',1,'Waiter::mergeTables()']]],
  ['mergetables_2eh_7',['MergeTables.h',['../MergeTables_8h.html',1,'']]],
  ['messages_8',['3. Commit Messages',['../md_README.html#autotoc_md15',1,'']]]
];
