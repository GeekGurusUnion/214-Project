var searchData=
[
  ['5_20class_20design_20and_20inheritance_0',['5. Class Design and Inheritance',['../md_README.html#autotoc_md8',1,'']]]
];
