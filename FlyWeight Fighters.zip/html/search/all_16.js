var searchData=
[
  ['removecomponent_0',['removeComponent',['../classfa__dish.html#a71400b890dc6558f780f8f1018517ff5',1,'fa_dish']]],
  ['removeingredienthandler_1',['removeingredienthandler',['../classRemoveingredientHandler.html',1,'RemoveingredientHandler'],['../classRemoveingredientHandler.html#a425079099f7c8148075b53f7c5672c69',1,'RemoveingredientHandler::RemoveingredientHandler()']]],
  ['removeitem_2',['removeItem',['../classOrder.html#a07e0943b8046410d91f2ff2c02074898',1,'Order']]],
  ['removetable_3',['removeTable',['../classFacade.html#a7d1e64af40d9d4e0d5af919a31854cfb',1,'Facade']]],
  ['repository_20rules_4',['1. Repository Rules',['../md_README.html#autotoc_md13',1,'']]],
  ['reset_5',['reset',['../classIterator.html#a32850eb6f82277c063362f18ac36affe',1,'Iterator::reset()'],['../classTableIterator.html#aec53369969e1a9e49d177c1b917cb290',1,'TableIterator::reset()'],['../classWaiterIterator.html#ae0ce6f5573eaefa765ccc17126e06237',1,'WaiterIterator::reset()']]],
  ['restauranttable_6',['restauranttable',['../classRestaurantTable.html',1,'RestaurantTable'],['../classRestaurantTable.html#a45363e30d3dadfcf6c4a0035e0f66832',1,'RestaurantTable::RestaurantTable()']]],
  ['restauranttable_2eh_7',['RestaurantTable.h',['../RestaurantTable_8h.html',1,'']]],
  ['rules_8',['1. Repository Rules',['../md_README.html#autotoc_md13',1,'']]]
];
