var searchData=
[
  ['7_20error_20handling_20and_20exceptions_0',['7. Error Handling and Exceptions',['../md_README.html#autotoc_md10',1,'']]]
];
