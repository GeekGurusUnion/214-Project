var searchData=
[
  ['bbqchickenpizza_0',['bbqchickenpizza',['../classBBQChickenPizza.html',1,'BBQChickenPizza'],['../classBBQChickenPizza.html#a898bd2ac3104be5b4d0e736f10171e5a',1,'BBQChickenPizza::BBQChickenPizza()']]],
  ['beefburger_1',['beefburger',['../classBeefBurger.html',1,'BeefBurger'],['../classBeefBurger.html#ae0adae71ec124512acd1692c3d3dd3f1',1,'BeefBurger::BeefBurger()']]],
  ['branches_2',['branches',['../md_README.html#autotoc_md17',1,'4.1. Main Branches'],['../md_README.html#autotoc_md18',1,'4.2. Supporting Branches'],['../md_README.html#autotoc_md19',1,'4.3. Feature Branches'],['../md_README.html#autotoc_md20',1,'4.4. Hotfix Branches']]],
  ['branching_3',['4. Branching',['../md_README.html#autotoc_md16',1,'']]]
];
