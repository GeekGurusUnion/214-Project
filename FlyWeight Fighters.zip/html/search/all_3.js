var searchData=
[
  ['4_201_20main_20branches_0',['4.1. Main Branches',['../md_README.html#autotoc_md17',1,'']]],
  ['4_202_20supporting_20branches_1',['4.2. Supporting Branches',['../md_README.html#autotoc_md18',1,'']]],
  ['4_203_20feature_20branches_2',['4.3. Feature Branches',['../md_README.html#autotoc_md19',1,'']]],
  ['4_204_20hotfix_20branches_3',['4.4. Hotfix Branches',['../md_README.html#autotoc_md20',1,'']]],
  ['4_20branching_4',['4. Branching',['../md_README.html#autotoc_md16',1,'']]],
  ['4_20functions_20and_20operators_5',['4. Functions and Operators',['../md_README.html#autotoc_md7',1,'']]]
];
