var searchData=
[
  ['unsetwaiter_0',['unsetWaiter',['../classRestaurantTable.html#a312b3a44bfe0f75aa3c5907879d641f6',1,'RestaurantTable']]],
  ['update_1',['update',['../classTableObserver.html#a50f9ba2bd933c9fed6e49935fab7911e',1,'TableObserver']]]
];
