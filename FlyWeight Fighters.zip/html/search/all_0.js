var searchData=
[
  ['1_20main_20branches_0',['4.1. Main Branches',['../md_README.html#autotoc_md17',1,'']]],
  ['1_20organizational_1',['1. Organizational',['../md_README.html#autotoc_md4',1,'']]],
  ['1_20repository_20rules_2',['1. Repository Rules',['../md_README.html#autotoc_md13',1,'']]]
];
