var searchData=
[
  ['6_20construction_20destruction_20and_20copying_0',['6. Construction, Destruction and Copying',['../md_README.html#autotoc_md9',1,'']]]
];
