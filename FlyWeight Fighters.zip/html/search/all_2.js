var searchData=
[
  ['3_20coding_20style_0',['3. Coding Style',['../md_README.html#autotoc_md6',1,'']]],
  ['3_20commit_20messages_1',['3. Commit Messages',['../md_README.html#autotoc_md15',1,'']]],
  ['3_20feature_20branches_2',['4.3. Feature Branches',['../md_README.html#autotoc_md19',1,'']]]
];
