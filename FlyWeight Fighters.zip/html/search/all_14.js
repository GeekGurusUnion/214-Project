var searchData=
[
  ['occupy_0',['occupy',['../classRestaurantTable.html#a385e5ac605152f50b869d8f06029765b',1,'RestaurantTable::occupy()'],['../classState.html#a6cd42dcaf83a233b60085d9f89856aa1',1,'State::occupy()'],['../classStateEmpty.html#acaef434021231bbf8a7622b30d1a972b',1,'StateEmpty::occupy()'],['../classStateOccupied.html#a90828578eb710be9e83729b161615a0d',1,'StateOccupied::occupy()'],['../classStateServe.html#a36a34ae9e84d8da24912b4be1fe995b2',1,'StateServe::occupy()']]],
  ['operators_1',['4. Functions and Operators',['../md_README.html#autotoc_md7',1,'']]],
  ['order_2',['order',['../classOrder.html',1,'Order'],['../classOrder.html#a1bb4ba37c82c1ae4646745f2a46ed8d4',1,'Order::Order()'],['../classColleague.html#a3139f737e1c30b3560822d73a1b97301',1,'Colleague::order']]],
  ['order_2eh_3',['Order.h',['../Order_8h.html',1,'']]],
  ['orderdetails_4',['orderDetails',['../classad__FloorOrder.html#a81151102b8db3fd6c77ac8d1ec503942',1,'ad_FloorOrder']]],
  ['organization_5',['Group Organization',['../md_README.html#autotoc_md1',1,'']]],
  ['organizational_6',['1. Organizational',['../md_README.html#autotoc_md4',1,'']]]
];
