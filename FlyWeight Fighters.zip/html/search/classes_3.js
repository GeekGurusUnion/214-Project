var searchData=
[
  ['doubleburger_0',['DoubleBurger',['../classDoubleBurger.html',1,'']]]
];
