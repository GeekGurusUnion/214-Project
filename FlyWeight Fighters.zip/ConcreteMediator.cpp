#include "ConcreteMediator.h"
#include "Mediator.h"

ConcreteMediator::ConcreteMediator() : Mediator() {}