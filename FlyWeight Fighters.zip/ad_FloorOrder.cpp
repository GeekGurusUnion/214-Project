#include "ad_FloorOrder.h"

std::vector<std::string> ad_FloorOrder::getDetails() const {
        return orderDetails;
}
ad_FloorOrder::~ad_FloorOrder() = default;
