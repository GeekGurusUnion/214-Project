var searchData=
[
  ['ingredienthandler_84',['ingredientHandler',['../classingredientHandler.html',1,'']]]
];
