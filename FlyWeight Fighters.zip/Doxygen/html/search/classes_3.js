var searchData=
[
  ['doubleburger_76',['DoubleBurger',['../classDoubleBurger.html',1,'']]]
];
