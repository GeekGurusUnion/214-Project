var searchData=
[
  ['ingredient_148',['ingredient',['../classingredientHandler.html#a23164e138a057f2bfd83cf9dc81c6177',1,'ingredientHandler']]]
];
