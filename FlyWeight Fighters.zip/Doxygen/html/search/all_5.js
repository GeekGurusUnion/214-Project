var searchData=
[
  ['getcustomizations_35',['getCustomizations',['../classad__RestaurantOrder.html#ad776a398c8baf77746f9a4429e853ed4',1,'ad_RestaurantOrder']]],
  ['getdescription_36',['getDescription',['../classfa__burger.html#a16569ff4576126d0fb7a51eb02142016',1,'fa_burger::getDescription()'],['../classfa__dish.html#aec33189257b0c7a7dd673d6374cfb2f0',1,'fa_dish::getDescription()'],['../classfa__Pizza.html#a79fa263375050206bc119fdb6e66d9c6',1,'fa_Pizza::getDescription()']]],
  ['getdetails_37',['getDetails',['../classad__FloorOrder.html#a597abe90e4ec5ed784eeb9ed8755c375',1,'ad_FloorOrder']]],
  ['getinstance_38',['getInstance',['../classsi__headChef.html#ab2dab262b5b7864063999ec0eae09adb',1,'si_headChef']]],
  ['getitem_39',['getItem',['../classad__RestaurantOrder.html#a353d42b0f732ca8b02bc29a21ea0c0b5',1,'ad_RestaurantOrder']]]
];
